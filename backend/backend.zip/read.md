# Knex

## Init

1. Criamos uma pasta para armazenar o banco sqlite em `./src/database/db.sqlite`
2. Executamos `npx Knex init` responsavel por criar o arquivo de configuração do Knex
3. Configuramos o arquivo para achar nosso arquivo do sqlite

```js
  development: {
    client: 'sqlite3',
    connection: {
      filename: './src/database/db.sqlite'
    },
    migrations: {
      directory: './src/database/migrations'
    },
    useNullAsDefault: true
  },
```

## Migrations

Cria duas funções uma para auteração na estrutura do banco e outra para reverter essa auteração.

1. Primeiro criamos uma pasta para armazenar os arquivos de migração `./src/database/migrations`
2. Execultamos um comando `npx Knex migrate:make nome_migration`

### Run migrations

_Rodas todas as migrations que inda não foram executadas_ `npx knex migrate:latest`
_Desfaz a ultima migration_ `npx knex migrate:rollback`
